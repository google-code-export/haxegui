chxdoc -o docs 					\
--includeOnly=haxegui.* 		\
--installTemplate=true 			\
--developer=true 				\
--showAuthorTags=true			\
--generateTodoFile=true 		\
--showTodoTags=true 			\
--headerText="haxegui"			\
--title="haxegui"				\
--subtitle="http://code.google.com/p/haxegui/"	\
--templateDir=docs/template		\
output.xml,flash9
