#!/bin/bash
make style 
make
make run

